#' Dataset with the articles and their time of release from 2013 to now
#'
#'
#' @docType data
#'
#' @usage data(CryptonewsData)
#'
#' @format Dataframe
#'
#' @keywords datasets
#'
#'
"CryptonewsData"
