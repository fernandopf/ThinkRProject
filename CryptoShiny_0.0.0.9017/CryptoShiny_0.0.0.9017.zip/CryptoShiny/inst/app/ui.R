CryptoShiny:::app_ui()
