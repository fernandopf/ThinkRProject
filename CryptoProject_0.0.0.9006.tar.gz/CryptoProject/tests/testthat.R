library(testthat)
library(CryptoProject)

test_check("CryptoProject")

