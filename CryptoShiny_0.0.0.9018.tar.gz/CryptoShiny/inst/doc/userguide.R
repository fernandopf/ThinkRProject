## ------------------------------------------------------------------------
library(CryptoShiny)

## ------------------------------------------------------------------------
bitcoinVsDollarExampleDay <- day_hour("day", "01/12/2017", "01/08/2018", "BTC", "USD")
head(bitcoinVsDollarExampleDay)

## ------------------------------------------------------------------------
exampleSameCryptocurrency <- day_hour("day", "01/12/2017", "01/08/2018", "BTC", "BTC")
head(exampleSameCryptocurrency)

## ------------------------------------------------------------------------

minuteExampleBTCvsUSD <- lastweek_minute("BTC", "USD")
head(minuteExampleBTCvsUSD)


## ------------------------------------------------------------------------
actualTime <- round(as.numeric(as.POSIXct(Sys.time(), format="%Y/%m/%d")))
exampleTsp <-  Tsp_data(actualTime) 
head(exampleTsp,1)

## ------------------------------------------------------------------------
#countNewsLastWeekBitcoin <- lastweek_news_counter("BTC")
#head(countNewsLastWeekBitcoin,1)

## ------------------------------------------------------------------------
bitcoinVsDollarExampleDay
CryptoNewsAnalysed <-CryptoNewsOccurencesDays[c("time", "BTC")]
colnames(CryptoNewsAnalysed) <- c("date", "news")
attr(CryptoNewsAnalysed$date, "tzone") <- "GMT"
CryptoNewsAnalysed$date <- CryptoNewsAnalysed$date + 3600
bitcoinVsDollarExampleDay <-bitcoinVsDollarExampleDay %>% dplyr::left_join(CryptoNewsAnalysed, by = "date")
#------------------------To put the news columns inside the dataframe--------------------


bitcoinVsDollarExampleWeek <- weekly_monthly_transformation(bitcoinVsDollarExampleDay, "week")
head(bitcoinVsDollarExampleWeek)

## ------------------------------------------------------------------------
bitcoinVsDollaFinancialIndicators <- averages(bitcoinVsDollarExampleWeek, 5, 26, 12, 9)
head(bitcoinVsDollaFinancialIndicators)

## ------------------------------------------------------------------------
exampleCryptoBTCUSDHour <- crypto("hour", "01/08/2018", "01/10/2018", "BTC", "USD",5 , 26, 12, 9)
tail(exampleCryptoBTCUSDHour)

## ------------------------------------------------------------------------
correlationBTCvsETH <- crypto_correlation("01/09/2018", "01/10/2018", "BTC", "ETH")
print(correlationBTCvsETH)

## ---- out.width = "600px"------------------------------------------------
candle_plot(data= exampleCryptoBTCUSDHour, MACD)

## ---- out.width = "600px"------------------------------------------------
candle_plot(data= exampleCryptoBTCUSDHour, volume)

## ---- out.width = "600px"------------------------------------------------
plot_lastweek(cryptocurrency = "EOS", comparison = "GBP", grouping = "6 hours")

## ------------------------------------------------------------------------
lastPrice <- getLastPriceMultiplePlatforms("BTC")
head(lastPrice)

## ------------------------------------------------------------------------
startday = "01/10/2018"
pocket_log <- data.frame("date" = as.POSIXct(startday,format="%d/%m/%Y", origin = "1970-01-01",tz = "GMT"),
                         "NetUSDvalue" = 1000,"USD" = 1000,"EUR" = 0, "GBP" = 0, "BTC" = 0, "ETH" = 0, "BNB" = 0, "BCC" = 0, "NEO" = 0, "LTC" = 0, "QTUM" = 0, "ADA" = 0, "XRP" = 0, "EOS" = 0, "TUSD" = 0, "IOTA" = 0, "XLM" = 0, "ONT" = 0, "TRX" = 0, "ETC" = 0, "ICX" = 0, "VEN" = 0, "NULS" = 0, "VET" = 0, "PAX" = 0)
head(pocket_log)

## ------------------------------------------------------------------------
pocket_log <- transaction(pocket = pocket_log, unit = 0.02, buycurrency = "BTC", sellcurrency = "USD", day = "05/12/2018")
pocket_log <- transaction(pocket = pocket_log, unit = 0.002, buycurrency = "BNB", sellcurrency = "USD", day = "07/12/2018")
pocket_log <- transaction(pocket = pocket_log, unit = 100, buycurrency = "EUR", sellcurrency = "USD", day = "10/12/2018")
pocket_log

## ------------------------------------------------------------------------
pocket_log <- transaction(pocket = pocket_log, unit = 100, buycurrency = "EUR", sellcurrency = "ETH", day = "10/12/2018", allowNegative = TRUE)
pocket_log

## ------------------------------------------------------------------------
pocket <- c("USD" = 1000, "BTC" = 10, "ETH" = 5)
NetUSDValue(pocket = pocket, day = "11/12/2018" )

## ------------------------------------------------------------------------
NetUSDValue(pocket = as.list(pocket_log[nrow(pocket_log),]),
            day = pocket_log[nrow(pocket_log),1] )

## ------------------------------------------------------------------------
pocket_log[nrow(pocket_log),2]

## ------------------------------------------------------------------------
#data <- dl_data_from(as.numeric(as.POSIXct("2013-11-25 1:00:00 EST")))
#write.csv(data, "CryptonewsData.csv")

## ------------------------------------------------------------------------
head(CryptonewsData)

## ------------------------------------------------------------------------
#interesting_crypto <- get_imp_Crp()
#interesting_crypto

## ------------------------------------------------------------------------
CryptoCurrencyName("BTC")
CryptoCurrencyName("ETH")

## ------------------------------------------------------------------------
# interesting_crypto <- c("BTC", "ETH", "LTC", "XMR", "USDT")
# result <- analyse_crps_news(CryptonewsData[seq(1,500,1),], interesting_crypto)
# head(result)

## ------------------------------------------------------------------------
# finalHour <- resTspToHour(result, interesting_crypto)
# write.csv(finalHour, "CryptoNewsOccurencesHour.csv")
# head(finalHour)
# finalDay <- resTspToDay(result, interesting_crypto)
# write.csv(finalDay, "CryptoNewsOccurencesDays.csv")
# head(finalDay)

## ------------------------------------------------------------------------
# updateHourNewsData()

## ------------------------------------------------------------------------
# updateDayNewsData()

## ---- out.width = "600px"------------------------------------------------
knitr::include_graphics("historical_1.png")

## ---- out.width = "600px"------------------------------------------------
knitr::include_graphics("minute_1.png")

## ---- out.width = "600px"------------------------------------------------
knitr::include_graphics("minute_2.png")

## ---- out.width = "600px"------------------------------------------------
knitr::include_graphics("price_comparison.png")

## ---- out.width = "600px"------------------------------------------------
knitr::include_graphics("trading_1.png")

## ---- out.width = "600px"------------------------------------------------
knitr::include_graphics("trading_2.png")

## ---- out.width = "600px"------------------------------------------------
knitr::include_graphics("trading_3.png")

## ---- out.width = "600px"------------------------------------------------
knitr::include_graphics("trading_4.png")

## ---- out.width = "600px"------------------------------------------------
knitr::include_graphics("trading_5.png")

