#' Dictionary with names of each crptocurrency and its symbol
#'
#'
#' @docType data
#'
#' @usage crp_dic
#'
#' @format Dataframe
#'
#' @keywords datasets
#'
#'
"crp_dic"
