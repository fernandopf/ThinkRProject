#' This is data to be included in my package
#'
#' @name coins
#' @docType data
#' @keywords data
"coins"
