#' Dataset with the number of occurences of cryptocurrencies in the news per hour
#'
#'
#' @docType data
#'
#' @usage data(CryptoNewsOccurencesHour)
#'
#' @format Dataframe
#'
#' @keywords datasets
#'
#'
"CryptoNewsOccurencesHour"
