CryptoShiny:::app_ui()
