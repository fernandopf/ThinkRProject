#' Dataset with the number of occurences of cryptocurrencies in the news per day
#'
#'
#' @docType data
#'
#' @usage data(CryptoNewsOccurencesDays)
#'
#' @format Dataframe
#'
#' @keywords datasets
#'
#'
"CryptoNewsOccurencesDays"
