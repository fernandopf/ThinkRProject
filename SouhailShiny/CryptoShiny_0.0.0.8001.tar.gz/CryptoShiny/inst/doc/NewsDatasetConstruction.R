## ------------------------------------------------------------------------
library(CryptoShiny)

## ------------------------------------------------------------------------
#data <- dl_data_from(as.numeric(as.POSIXct("2013-11-25 1:00:00 EST")))
#write.csv(data, "CryptonewsData.csv")

## ------------------------------------------------------------------------
head(CryptonewsData)

## ------------------------------------------------------------------------
interesting_crypto <- get_imp_Crp()
interesting_crypto

## ------------------------------------------------------------------------
CryptoCurrencyName("BTC")
CryptoCurrencyName("ETH")

## ------------------------------------------------------------------------
interesting_crypto <- c("BTC", "ETH", "LTC", "XMR", "USDT")
result <- analyse_crps_news(CryptonewsData[seq(1,500,1),], interesting_crypto)
head(result)

## ------------------------------------------------------------------------
finalHour <- resTspToHour(result, interesting_crypto)
#write.csv(finalHour, "CryptoNewsOccurencesHour.csv")
head(finalHour)
finalDay <- resTspToDay(result, interesting_crypto)
#write.csv(finalDay, "CryptoNewsOccurencesDays.csv")
head(finalDay)

## ------------------------------------------------------------------------
updateHourNewsData()

## ------------------------------------------------------------------------
updateDayNewsData()

## ------------------------------------------------------------------------
df1 <- day_hour("day", "01/02/2018", "01/12/2018", "BTC", "USD")
df1

## ------------------------------------------------------------------------
library(readr)
library(tidyverse)
CryptoNewsAnalysedDays <- read_csv("../data-raw/CryptoNewsAnalysedDays.csv")
CryptoNewsAnalysedDays <- CryptoNewsAnalysedDays[c("time", "BTC")]
colnames(CryptoNewsAnalysedDays) <- c("date", "news")

CryptoNewsAnalysedDays
df1 %>% left_join(CryptoNewsAnalysedDays, by = "date") 

