library(testthat)
library(CryptoShiny)

test_check("CryptoShiny")

