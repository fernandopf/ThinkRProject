## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(dplyr)
library(jsonlite)
#library(lubridate)
#library(pracma)

## ------------------------------------------------------------------------
day_hour <- function(timeframe, firstDay, lastDay, crytocurrenty = "BTC", comparison = "USD") {
  library(dplyr)
  library(jsonlite)

  # Date
  firstDay <- as.Date(firstDay,format="%d/%m/%Y")
  lastDay <- as.Date(lastDay,format="%d/%m/%Y")

  time <- round(as.numeric(as.POSIXct(lastDay, format="%m/%d/%Y")))

  # Number of points of hour dataframe
  n <- as.numeric(lastDay-firstDay)

  if (timeframe %in% c("Day", "day")){
    a <- "histoday"
    incr <- 3600*24
  }
  else if (timeframe %in% c("Hour", "hour")) {
    a <- "histohour"
    n <- round(n*24)
    incr <- 3600
  }
  else {
    print('No valid timeframe')
    return();
  }

  # Maximum number of points is 2000
  if (n <= 2000) {
    link <- paste("https://min-api.cryptocompare.com/data/", a,"?fsym=",crytocurrenty, "&tsym=", comparison,"&limit=", n, "&aggregate=1&toTs=",time, "&extraParams=ThinkR", sep = "")
    linkVolume <- paste("https://min-api.cryptocompare.com/data/exchange/", a,"?tsym=",crytocurrenty,"&limit=", n, "&toTs=",time, "&extraParams=ThinkR", sep = "")
    dataPrice <- fromJSON(link)
    dataVolume <- fromJSON(linkVolume)
    df <- data.frame(
      date= as.POSIXct(dataPrice$Data$time,origin = "1970-01-01",tz = "GMT"),
      high=dataPrice$Data$high,
      low = dataPrice$Data$low,
      open = dataPrice$Data$open,
      close = dataPrice$Data$close,
      volume = dataVolume$Data$volume
    )
  }
  # If the number of points is higher than the maximum we need to do a for loop
  else {
    # Round to the highest Integuer
    iterations <- ceiling(n/2000)
    n1 <- 2000
    for (i in 1:iterations){
      if (i ==iterations){
        n1 =n-2000*(iterations-1)
      }
      linkPrice <- paste("https://min-api.cryptocompare.com/data/", a,"?fsym=",crytocurrenty, "&tsym=", comparison,"&limit=", n1, "&aggregate=1&toTs=",time, "&extraParams=ThinkR", sep = "")
      linkVolume <- paste("https://min-api.cryptocompare.com/data/exchange/", a,"?tsym=",crytocurrenty,"&limit=", n1, "&toTs=",time, "&extraParams=ThinkR", sep = "")
      dataPrice <- fromJSON(linkPrice)
      dataVolume <- fromJSON(linkVolume)
      df1 <- data.frame(
        date= as.POSIXct(dataPrice$Data$time,origin = "1970-01-01",tz = "GMT"),
        high=dataPrice$Data$high,
        low = dataPrice$Data$low,
        open = dataPrice$Data$open,
        close = dataPrice$Data$close,
        volume = dataVolume$Data$volume
      )
      if (i ==1){
        df <- df1
      } else {
        df <- rbind(df, df1)
      }
      time <- time - 2000*incr
    }
  }
  df <-df %>%
  mutate(direction = ifelse(open >close, "increasing", "decreasing")) %>%
  arrange(date)
  return(df)
}

## ------------------------------------------------------------------------
example1 <- day_hour("day", "01/12/2017", "01/08/2018", "BTC", "USD")
head(example1)

## ------------------------------------------------------------------------
lastweek_minute <- function(crytocurrenty = "BTC", comparison = "USD") {
  
  library(dplyr)
  library(jsonlite)

  actualTime <- round(as.numeric(Sys.time()))
  MaxLimit <- as.numeric(Sys.time()-as.difftime(7, units="days"))

  # Number of points of  dataframe
  n <- round(actualTime-MaxLimit)/60

  # Round to the highest Integuer
  iterations <- ceiling(n/2000)

  # Set the time equal to the actual
  time = actualTime
  n1 <- 2000
  for (i in 1:iterations){
    if (i ==iterations){
      n1 =n-2000*(iterations-1)
    }
    link <- paste("https://min-api.cryptocompare.com/data/histominute?fsym=",crytocurrenty, "&tsym=", comparison,"&limit=", n1, "&aggregate=1&toTs=",time, "&extraParams=your_app_name", sep = "")
    data <- fromJSON(link)
    df1 <- data.frame(
      date= as.POSIXct(data$Data$time,origin = "1970-01-01",tz = "GMT"),
      high=data$Data$high,
      low = data$Data$low,
      open = data$Data$open,
      close = data$Data$close
    )
    if (i ==1){
      df <- df1
    } else {
      df <- rbind(df, df1)
    }
    time <- time - 2000*60
  }

  df <-df %>%
  mutate(direction = ifelse(open >close, "increasing", "decreasing")) %>%
  arrange(date)
  
  return(df)
}

## ------------------------------------------------------------------------
example2 <- lastweek_minute("BTC", "USD")
head(example2)

## ----message=TRUE, warning=FALSE-----------------------------------------
weekly_monthly_transformation <- function(df, timeframe){
  library(lubridate)
  library(dplyr)
  
  if (timeframe %in% c("Month", "month")){
df.transformed <- df %>% 
  group_by(date = floor_date(date, "month")) %>% 
  summarise(high = max(high), low = min(low), open = head(open, n = 1), close = tail(close, n = 1), volume = sum(volume))
  }
  else if (timeframe %in% c("Week", "week")){
df.transformed <- df %>% 
  group_by(date = floor_date(date, "week")) %>% 
  summarise(high = max(high), low = min(low), open = head(open, n = 1), close = tail(close, n = 1), volume = sum(volume))
  }
  return(df.transformed)
}

## ------------------------------------------------------------------------
example2 <- weekly_monthly_transformation(example1, "week")
head(example2)

## ------------------------------------------------------------------------
averages <- function(df, n_MA, n_quick_MACD, n_slow_MACD, n_signal_MACD){
library(pracma)
 out <- df %>% 
  mutate(daily_average = (high +low)/2)  %>% 
  mutate(MA = movavg(x = daily_average, n = n_MA, type = "s")) %>% 
  mutate(quick_EMA = movavg(x = daily_average, n = n_quick_MACD, type = "e")) %>% 
  mutate(slow_EMA = movavg(x = daily_average, n = n_slow_MACD, type = "e")) %>% 
  mutate(signal_MACD = movavg(x = daily_average, n = n_signal_MACD, type = "e")) %>%
  mutate(MACD = quick_EMA - slow_EMA)
return(out)
}


## ------------------------------------------------------------------------
averages(example2, 5, 26, 12, 9)

## ------------------------------------------------------------------------
crypto <- function(timeframe, firstDay, lastDay, crytocurrenty = "BTC", comparison = "USD", n_MA, n_quick_MACD, n_slow_MACD, n_signal_MACD){
  if (timeframe %in% c("Week", "week", "Month", "month")){
    df <- day_hour(timeframe = "day", firstDay, lastDay, crytocurrenty, comparison); 
    df.transformed <- weekly_monthly_transformation(df, timeframe);
    df.averaged <- averages(df.transformed, n_MA, n_quick_MACD, n_slow_MACD, n_signal_MACD)
  }
  else {
    df <- day_hour(timeframe, firstDay, lastDay, crytocurrenty, comparison);
    df.averaged <- averages(df,n_MA, n_quick_MACD, n_slow_MACD, n_signal_MACD)
  }
  return(df.averaged)
}

## ------------------------------------------------------------------------
example3 <- crypto("week", "01/12/2017", "01/08/2018", "BTC", "USD",5, 26, 12, 9)
tail(example3)

## ------------------------------------------------------------------------
example4 <- crypto("hour", "01/07/2018", "01/08/2018", "BTC", "USD",5, 26, 12, 9)
tail(example4)

